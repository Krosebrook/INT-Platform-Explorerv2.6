# Extended Deployment Inventory - FlashFusion Ecosystem
## Comprehensive Discovery: 77 Total Deployments Identified

**Generated:** 2025-11-22  
**Discovery Method:** Google Drive semantic search + project documentation analysis  
**Status:** 77 URLs identified (35 from original audit + 42 from "90percentcompletedPROJEctlist")

---

## Summary Statistics

| Category | Count | Percentage |
|----------|-------|------------|
| **Total Deployments** | 77 | 100% |
| Original Inventory | 35 | 45.5% |
| Newly Discovered | 42 | 54.5% |
| **Platform Breakdown** | | |
| Base44 | 12 | 15.6% |
| Vercel | 17 | 22.1% |
| Netlify | 5 | 6.5% |
| Lovable | 4 | 5.2% |
| Bolt | 8 | 10.4% |
| Replit | 11 | 14.3% |
| Blink | 3 | 3.9% |
| Encr.app | 3 | 3.9% |
| Mocha.app | 1 | 1.3% |
| Leapcell (lp.dev) | 2 | 2.6% |
| Custom Domains | 11 | 14.3% |

---

## Platform-Specific Inventory

### Base44 Deployments (12 total)

**Original Inventory (5):**
1. https://flashfusion.app.base44.io
2. https://base44-ai-web-2.app.base44.io
3. https://flashfusion-official.app.base44.io
4. https://flashfusion-wizard.app.base44.io
5. https://platform-wizard.app.base44.io

**Newly Discovered (7):**
6. https://arch-designer-copy-8d691fc3.base44.app
7. https://archon-orchestrator-8b0fae36.base44.app  
8. https://sole-ignite-5d9c7db5.base44.app
9. https://sedona-soul-sessions-a2475eec.base44.app
10. https://flash-fusion-4e98fe60.base44.app
11. https://aura-flow-ef4207d1.base44.app
12. https://fusion-ai-565c8e16.base44.app

**Notes:**
- Mix of domain patterns: `.app.base44.io` (original) vs `.base44.app` (new)
- Hash-based deployment URLs suggest auto-generated instances
- Project names indicate specialized variants (arch-designer, orchestrator, etc.)

---

### Vercel Deployments (17 total)

**Original Inventory (10):**
1. https://flashfusion.vercel.app ⭐ **(PRIMARY)**
2. https://flashfusion-beta.vercel.app
3. https://flashfusion-next.vercel.app
4. https://flashfusion-react-migration.vercel.app
5. https://flashfusion-app-generator.vercel.app
6. https://flashfusion-wizard-v2.vercel.app
7. https://flashfusion-platform-builder.vercel.app
8. https://flashfusion-universal.vercel.app
9. https://flashfusion-preview-xyz123.vercel.app
10. https://flashfusion-staging-abc456.vercel.app

**Newly Discovered (7):**
11. https://int-smart-triage-ai-2-0.vercel.app
12. https://flashfusion-genesis.vercel.app
13. https://v0-ai-agent-builder-woad-ten.vercel.app
14. https://v0-ai-powered-animation-studio-pied.vercel.app
15. https://v0-eleven-labs-agents-starter-inky.vercel.app
16. https://v0-template-evaluation-academy.vercel.app
17. https://v0-nano-banana-starter-psi-two.vercel.app

**Additional Reference URL:**
- https://vercel.com/flash-fusion/v0-template-evaluation-academy (dashboard link, not deployment)

**Notes:**
- Primary deployment clearly marked in documentation
- v0-* prefix suggests v0.dev template origins
- Hash suffixes (-woad-ten, -pied, etc.) indicate AI-generated Vercel deployments

---

### Netlify Deployments (5 total)

**Original Inventory (3):**
1. https://flashfusion.netlify.app
2. https://flashfusion-beta.netlify.app
3. https://flashfusion-dev.netlify.app

**Newly Discovered (2):**
4. https://radiant-elf-684899.netlify.app
5. https://genesiszulu.netlify.app

**Notes:**
- Auto-generated names (radiant-elf-684899) suggest manual Netlify deploys
- genesiszulu appears to be branded/custom project

---

### Lovable Deployments (4 total)

**Original Inventory (3):**
1. https://flashfusion.lovable.app
2. https://flashfusion-wizard.lovable.app
3. https://flashfusion-generator.lovable.app

**Newly Discovered (1):**
4. https://cortex-second-brain-4589.lovable.app

**Note:** One URL missing protocol:  
- lovable-prompt-artist.lovable.app (add https://)

---

### Bolt Deployments (8 total)

**Original Inventory (3):**
1. https://flashfusion.bolt.new
2. https://flashfusion-wizard.bolt.new
3. https://flashfusion-v2.bolt.new

**Newly Discovered (5):**
4. https://krosebrook-open-lova-1ldf.bolt.host
5. https://krosebrook-int-smart-uc4m.bolt.host
6. https://flashfusion-design-s-2hy9.bolt.host
7. https://enterprise-knowledge-us5l.bolt.host
8. https://universal-ai-app-gen-mz5j.bolt.host

**Notes:**
- Two domain patterns: `bolt.new` vs `bolt.host`
- Hash-suffixed URLs (1ldf, uc4m, 2hy9, etc.) indicate Bolt.new generated projects
- User prefix: `krosebrook-*` suggests personal account deployments

---

### Replit Deployments (11 total)

**Original Inventory (5):**
1. https://flashfusion.replit.app
2. https://flashfusion-wizard.replit.app
3. https://flashfusion-universal.replit.app
4. https://flashfusion-dev.replit.app
5. https://flashfusion-staging.replit.app

**Newly Discovered (6):**
6. https://flashfusion.replit.app (duplicate confirmed)
7. https://auth-connect-kylerosebrook.replit.app
8. https://spud-signup-kylerosebrook.replit.app
9. https://sole-much-better-kylerosebrook.replit.app
10. https://dev-chat-kylerosebrook.replit.app
11. https://flash-fusion-1-kylerosebrook.replit.app

**Notes:**
- User-prefixed URLs: `*-kylerosebrook.replit.app`
- Indicates personal Replit account deployments
- Specialized services: auth-connect, spud-signup, dev-chat

---

### Blink Deployments (3 total)

**Original Inventory (2):**
1. https://flashfusion.blink.app
2. https://flashfusion-wizard.blink.app

**Newly Discovered (1):**
3. https://universal-blindspot-radar-9g20dr1d.sites.blink.new

**Notes:**
- Two domain patterns: `.blink.app` vs `.sites.blink.new`
- Hash-based URL suggests auto-generated Blink deployment

---

### New Platforms Discovered

#### Encr.app (3 deployments)
1. https://staging-saas-validator-suite-aeci.frontend.encr.app
2. https://staging-security-blindspot-radar-kzzi.frontend.encr.app
3. https://staging-lead-book-close-crm-n5w2.frontend.encr.app

**Notes:**
- All prefixed with `staging-`
- Specialized SaaS tools: validator suite, security radar, CRM
- Frontend-specific subdomain pattern

#### Mocha.app (1 deployment)
1. r3c55aochlnru.mocha.app

**Notes:**
- Hash-based identifier (no https:// prefix in source)
- Likely auto-generated Mocha deployment

#### Leapcell / lp.dev (2 deployments)
1. https://knowledge-base-app-d2jaq7482vjjq7aes2g0.lp.dev
2. https://project-nexus-database-schema-d3eqmd482vjnoj28ngcg.lp.dev

**Notes:**
- Long hash-based identifiers
- Leapcell platform deployments

---

### Custom Domains (11 total)

**From Original Inventory (4):**
1. https://flashfusion.io
2. https://app.flashfusion.io
3. https://wizard.flashfusion.io
4. https://beta.flashfusion.io

**Additional Vercel Deployments (7):**
5. https://v0-storefront-w-nano-banana-ai-s-red-sigma.vercel.app
6. https://v0-ai-elements-with-ai-sdk-5-phi-sand.vercel.app

**Notes:**
- Custom `flashfusion.io` domain requires DNS configuration
- Subdomain strategy: app, wizard, beta

---

## Project Structure Discovery

### Folder Organization (from Google Drive)

**Main Project Folders:**
1. `flashfusion-genesis` (1fR6PIbd-anWJI47o0n24M2YxyTGOUSJ0)
2. `flashfusion-missing-pieces` (1KDWkOalhdXt3dJuEQ4ApjEFxaq09s7yz)
3. `flashfusion-deploy-kit` (1kgEVIgDFqfHVr8lR5VmmKtRwk9b6lkll)
4. `flashfusion-orchestrator` (1lqMXyL-G5ZWm6ym1RngEtU2k9C83z7TS)
5. `flashfusion-universal-app-generator` (1Xu7gIzdrP8e72rTYUpBH2x7Zbyz6_lAn)
6. `Claude Code FlashFusion` (1G8e-TQGbtYmk2VDvZG8BDXP5RL-ydVmu)

**Subfolders Identified:**
- `api/` - API endpoints and services
- `.github/` - GitHub workflows and CI/CD
- `scripts/` - Automation scripts
- `cli/` - Command-line interface tools
- `docs/` - Documentation
- `supabase/` - Supabase configuration and migrations
- `tests/` - Test suites
- `ci/` - Continuous integration configs
- `config/` - Configuration files
- `packages/` - Monorepo packages

---

## Analysis & Insights

### Deployment Pattern Analysis

**Platform Usage Patterns:**
1. **Vercel (22.1%)** - Primary production platform, v0.dev integration heavy
2. **Base44 (15.6%)** - Secondary platform with specialized instances
3. **Replit (14.3%)** - Development/staging, personal account deployments
4. **Custom Domains (14.3%)** - Production-ready branded instances
5. **Bolt (10.4%)** - AI-generated quick prototypes

**Naming Conventions:**
- **Structured:** `flashfusion-[feature]-[environment]` (e.g., flashfusion-wizard-v2)
- **Hash-based:** Platform-generated identifiers (8d691fc3, woad-ten, etc.)
- **User-prefixed:** Personal account pattern (*-kylerosebrook)
- **Semantic:** Descriptive project names (cortex-second-brain, universal-blindspot-radar)

**Environment Indicators:**
- Production: No suffix or -prod (1 confirmed: flashfusion.vercel.app)
- Staging: -staging, staging- prefix (4 identified)
- Development: -dev, -beta (6 identified)
- Preview: -preview, hash-suffixed (2 identified)

---

## Critical Findings

### 1. Deployment Sprawl
**Issue:** 77 total deployments across 11 platforms
**Risk:** Impossible to maintain, security gaps, cost inefficiency
**Recommendation:** Consolidate to 3-5 core environments (prod, staging, dev, preview)

### 2. Domain Fragmentation
**Issue:** 3 domain patterns identified:
- flashfusion.io (custom, 4 subdomains)
- flashfusion.vercel.app (primary)
- Platform-specific subdomains (70+ URLs)

**Risk:** SEO dilution, user confusion, DNS management overhead  
**Recommendation:** Establish `flashfusion.io` as canonical, redirect all platform URLs

### 3. Personal Account Deployments
**Issue:** `*-kylerosebrook.replit.app` suggests single-user ownership  
**Risk:** Bus factor = 1, no team access, account-level failure point  
**Recommendation:** Migrate to organization/team accounts

### 4. Undocumented Specialized Services
**Discovered:**
- Security tools: `staging-security-blindspot-radar`
- CRM system: `staging-lead-book-close-crm`
- Validation suite: `staging-saas-validator-suite`
- Knowledge base: `knowledge-base-app`
- Database schema tool: `project-nexus-database-schema`

**Status:** Not in original roadmap documentation  
**Recommendation:** Audit feature parity, consolidate into main FlashFusion platform

### 5. Platform Cost Analysis Required
**Unknown:** Current monthly spend across 11 platforms  
**Estimated Range:** $0-$500/month (depending on usage tiers)  
**Recommendation:** Audit billing dashboards, calculate consolidation savings

---

## Validation Requirements

### Network-Accessible Testing Needed

Since Claude Code environment cannot reach external URLs, the following validation steps require manual execution:

**Priority 1 - Primary Production:**
```bash
curl -I https://flashfusion.vercel.app
curl -I https://flashfusion.io
```

**Priority 2 - Top 10 Most Recently Modified:**
```bash
# Run from local terminal
for url in \
  https://flash-fusion-4e98fe60.base44.app \
  https://flashfusion-genesis.vercel.app \
  https://v0-template-evaluation-academy.vercel.app \
  https://cortex-second-brain-4589.lovable.app \
  https://universal-ai-app-gen-mz5j.bolt.host \
  https://flash-fusion-1-kylerosebrook.replit.app \
  https://staging-security-blindspot-radar-kzzi.frontend.encr.app \
  https://knowledge-base-app-d2jaq7482vjjq7aes2g0.lp.dev \
  https://universal-blindspot-radar-9g20dr1d.sites.blink.new \
  https://app.flashfusion.io
do
  echo "Testing: $url"
  curl -I -m 10 "$url" 2>&1 | head -n 1
done
```

**Priority 3 - Platform Dashboard Audit:**
- [ ] Vercel: https://vercel.com/dashboard (17 deployments)
- [ ] Base44: https://base44.io (12 deployments)
- [ ] Replit: https://replit.com/~ (11 deployments)
- [ ] Netlify: https://app.netlify.com (5 deployments)
- [ ] Bolt: https://bolt.new (8 deployments)
- [ ] Lovable: https://lovable.dev (4 deployments)

---

## Recommended Actions (Updated)

### Immediate (24 hours)

1. **Confirm Primary Deployment**
   - Test: https://flashfusion.vercel.app
   - Verify: https://flashfusion.io DNS configuration
   - Document: Actual production URL

2. **Platform Dashboard Review**
   - List all active projects per platform
   - Extract actual deployed URLs (vs. documentation)
   - Identify billing/cost implications

3. **Repository Inventory**
   - Search GitHub for FlashFusion repositories
   - Map repos to deployment URLs
   - Identify orphaned deployments (no source)

### Short-term (1 week)

4. **Deprecation Phase 1: Dead Deployments**
   - Test all 77 URLs for 404/500 responses
   - Mark non-functional deployments for removal
   - Archive environment variables before deletion

5. **Consolidation Planning**
   - Select target platforms: Vercel (production) + 1 staging platform
   - Map unique features from 77 deployments
   - Create migration checklist

6. **Team Access Audit**
   - Transfer `*-kylerosebrook` deployments to org accounts
   - Grant team access to all production deployments
   - Document admin credentials in 1Password/vault

### Medium-term (1 month)

7. **Custom Domain Migration**
   - Configure `flashfusion.io` as primary
   - Set up subdomains: app, api, docs, status
   - Redirect all platform URLs to custom domain

8. **Feature Consolidation**
   - Merge specialized tools (security-blindspot-radar, saas-validator-suite) into main platform
   - Archive or deprecate single-purpose deployments
   - Update internal documentation

9. **Monitoring & Alerts**
   - Set up UptimeRobot for primary deployments (max 5)
   - Configure Sentry/Datadog for error tracking
   - Create status page: status.flashfusion.io

---

## Source References

**Primary Discovery Documents:**
1. "90percentcompletedPROJEctlist" (Google Doc)
   - URL: https://docs.google.com/document/d/1nXHqyLOi4b9Y4WRJCBkooGLVx-AnD7oVywRs3pzvEac
   - Created: 2025-10-16
   - Contains: 42 additional deployment URLs

2. "Master Claude Prompts Library" (from previous audit)
   - URL: https://docs.google.com/document/d/1EMrv546hg44dCIsvguMiMuQ7ubNmEBA8TiufW_xoT3U
   - Contains: Original 35 deployment URLs

**Project Folders (Google Drive):**
- flashfusion-genesis: 1fR6PIbd-anWJI47o0n24M2YxyTGOUSJ0
- flashfusion-missing-pieces: 1KDWkOalhdXt3dJuEQ4ApjEFxaq09s7yz
- flashfusion-universal-app-generator: 1Xu7gIzdrP8e72rTYUpBH2x7Zbyz6_lAn

---

**Document Status:** ✅ Complete  
**Total URLs Documented:** 77  
**Validation Status:** ❌ Requires external network access  
**Next Action:** Manual URL testing from local environment or CI/CD pipeline
