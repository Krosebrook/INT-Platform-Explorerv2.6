# Vercel Deployments - Complete Specifications
## 17 Instances | Primary Production Platform

**Generated:** 2025-11-22  
**Platform:** Vercel  
**Total Deployments:** 17  
**Status:** 🟡 Unverified (Network Restricted)  
**Monthly Cost Estimate:** $0-$340 (Hobby to Pro tiers)

---

## Platform Overview

### Strategic Importance
- **Production Platform:** ⭐ Primary deployment target
- **Primary URL:** https://flashfusion.vercel.app
- **Custom Domain Target:** flashfusion.io (pending DNS configuration)
- **CI/CD Integration:** GitHub Actions (assumed)
- **Edge Network:** Global CDN (180+ regions)

### Vercel Tier Analysis

| Tier | Cost/mo | Deployments | Build Minutes | Bandwidth |
|------|---------|-------------|---------------|-----------|
| Hobby | $0 | Unlimited | 6,000 min | 100 GB |
| Pro | $20 | Unlimited | 24,000 min | 1 TB |
| Enterprise | Custom | Unlimited | Custom | Custom |

**Current Unknown:** Actual tier(s) in use across 17 deployments

---

## Deployment Inventory

### 1. flashfusion.vercel.app ⭐ **[PRIMARY]**

**Status:** 🟡 Unverified  
**Purpose:** Main production deployment  
**Priority:** P0 - CRITICAL

#### Technical Stack (Assumed)
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Build Command: npm run build
Output Directory: .next
Install Command: npm install
```

#### Environment Variables (Schema)
```bash
# Database
DATABASE_URL=<supabase_postgres_url>
DIRECT_URL=<supabase_direct_url>

# Auth
NEXT_PUBLIC_SUPABASE_URL=<supabase_project_url>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<supabase_anon_key>
SUPABASE_SERVICE_ROLE_KEY=<supabase_service_key>

# API Keys
OPENAI_API_KEY=<openai_key>
ANTHROPIC_API_KEY=<anthropic_key>

# App Config
NEXT_PUBLIC_APP_URL=https://flashfusion.vercel.app
NEXT_PUBLIC_ENVIRONMENT=production
```

#### Infrastructure
```yaml
Region: Global Edge Network (auto)
Compute: Serverless Functions
Build Time: ~3-5 minutes (estimated)
Cold Start: <200ms (Next.js optimized)
```

#### Security & Access
```yaml
Authentication: Supabase Auth (assumed)
Authorization: Row Level Security (RLS)
CORS: Configured for flashfusion.io
Security Headers:
  - X-Frame-Options: DENY
  - X-Content-Type-Options: nosniff
  - Referrer-Policy: origin-when-cross-origin
```

#### CI/CD Pipeline (Assumed)
```yaml
Trigger: Git push to main branch
Source: GitHub repository (kylerosebrook/flashfusion)
Auto Deploy: Yes
Preview Deployments: Yes (PR-based)
Build Cache: Enabled
```

#### Monitoring & Observability
```yaml
Analytics: Vercel Analytics (built-in)
Logs: Vercel Log Drain (if configured)
APM: Unknown (Sentry/Datadog recommended)
Uptime Monitoring: None identified (UptimeRobot recommended)
```

#### Deprecation Analysis
```yaml
Recommendation: KEEP - Migrate to flashfusion.io custom domain
Migration Complexity: Low (DNS configuration only)
Unique Features: Primary production instance
Deprecation Priority: N/A - This is the target
```

---

### 2. flashfusion-beta.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Beta testing environment  
**Priority:** P2 - Evaluate for staging

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Build Command: npm run build
Environment: Staging/Beta
```

#### Environment Variables (Differences from Production)
```bash
NEXT_PUBLIC_APP_URL=https://flashfusion-beta.vercel.app
NEXT_PUBLIC_ENVIRONMENT=beta
# Likely uses separate Supabase project or staging DB
```

#### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE → flashfusion-staging.vercel.app
Migration Complexity: Low
Unique Features: Beta feature flags (if any)
Deprecation Priority: P2 - Consolidate within 1 month
```

---

### 3. flashfusion-next.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Next.js version testing or feature branch  
**Priority:** P3 - Likely redundant

#### Technical Stack
```yaml
Runtime: Node.js 20.x (or testing newer version)
Framework: Next.js 15.x (canary/rc?)
Purpose: Framework version testing
```

#### Deprecation Analysis
```yaml
Recommendation: DEPRECATE - Use Vercel preview deployments
Migration Complexity: Low (no unique features expected)
Unique Features: None identified
Deprecation Priority: P1 - Deprecate immediately
```

---

### 4. flashfusion-react-migration.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** React migration experiment (legacy)  
**Priority:** P4 - Archive candidate

#### Technical Stack
```yaml
Framework: Transitional (React → Next.js?)
Status: Likely abandoned
Purpose: Historical migration artifact
```

#### Deprecation Analysis
```yaml
Recommendation: ARCHIVE & DELETE
Migration Complexity: N/A (no features to migrate)
Unique Features: None (historical only)
Deprecation Priority: P0 - Delete immediately
```

---

### 5. flashfusion-app-generator.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Core app generator feature isolated deployment  
**Priority:** P1 - High value

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Focus: Universal App Generator wizard
```

#### Environment Variables (Specialized)
```bash
# AI Generation
OPENAI_API_KEY=<key>
ANTHROPIC_API_KEY=<key>

# Code Generation
GITHUB_TOKEN=<token_for_repo_creation>
VERCEL_TOKEN=<token_for_deployment>

# Template Registry
TEMPLATE_REGISTRY_URL=<url>
```

#### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE into primary (flashfusion.vercel.app)
Migration Complexity: Medium (feature integration required)
Unique Features: App generator wizard, template system
Deprecation Priority: P2 - Migrate core features, then deprecate
```

---

### 6. flashfusion-wizard-v2.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Version 2 of configuration wizard  
**Priority:** P2 - Feature comparison needed

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Focus: Multi-step wizard UI
```

#### Deprecation Analysis
```yaml
Recommendation: EVALUATE v1 vs v2, consolidate best version
Migration Complexity: Medium (UI component library)
Unique Features: Wizard v2 improvements (unknown specifics)
Deprecation Priority: P2 - After feature audit
```

---

### 7. flashfusion-platform-builder.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Platform/architecture design tool  
**Priority:** P2 - Specialized feature

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Focus: Visual platform architecture builder
```

#### Environment Variables (Specialized)
```bash
# Diagram/Canvas
CANVAS_RENDERER=konva|fabric
EXPORT_FORMAT=svg,png,json

# Architecture Templates
PLATFORM_TEMPLATES_URL=<url>
```

#### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE if actively used
Migration Complexity: High (canvas/diagram tooling)
Unique Features: Visual architecture designer
Deprecation Priority: P3 - Evaluate usage metrics first
```

---

### 8. flashfusion-universal.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Universal app generator variant  
**Priority:** P2 - Possible duplicate of #5

#### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE with flashfusion-app-generator
Migration Complexity: Low (likely duplicate)
Unique Features: Unknown (compare with #5)
Deprecation Priority: P2 - Audit vs app-generator
```

---

### 9. flashfusion-preview-xyz123.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** PR preview deployment (example hash)  
**Priority:** P4 - Auto-generated, ephemeral

#### Technical Stack
```yaml
Type: Vercel Preview Deployment
Lifecycle: Temporary (PR-based)
Auto-Delete: 30 days after PR merge/close
```

#### Deprecation Analysis
```yaml
Recommendation: KEEP PATTERN - Do not manually manage
Migration Complexity: N/A (auto-managed)
Unique Features: None (transient preview)
Deprecation Priority: N/A - Auto-expires
```

---

### 10. flashfusion-staging-abc456.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Staging environment (example hash)  
**Priority:** P1 - Staging target

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Environment: Staging
```

#### Environment Variables
```bash
NEXT_PUBLIC_ENVIRONMENT=staging
# Uses staging database & services
```

#### Deprecation Analysis
```yaml
Recommendation: STANDARDIZE as flashfusion-staging.vercel.app
Migration Complexity: Low (rename deployment)
Unique Features: Staging environment config
Deprecation Priority: P1 - Rename, keep as staging
```

---

### 11. int-smart-triage-ai-2-0.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Intelligent triage/routing system  
**Priority:** P2 - Specialized AI feature

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+ or standalone API
Focus: AI-powered ticket/issue triage
```

#### Environment Variables (AI-Specific)
```bash
# AI Models
OPENAI_API_KEY=<key>
ANTHROPIC_API_KEY=<key>

# Triage Config
TRIAGE_RULES_URL=<rules_engine>
ESCALATION_WEBHOOK=<webhook_url>

# Integration
GITHUB_TOKEN=<for_issue_integration>
LINEAR_API_KEY=<for_linear_integration>
```

#### Deprecation Analysis
```yaml
Recommendation: EVALUATE integration potential
Migration Complexity: Medium (AI routing logic)
Unique Features: Smart triage, AI routing
Deprecation Priority: P3 - Product decision required
```

---

### 12. flashfusion-genesis.vercel.app

**Status:** 🟡 Unverified  
**Purpose:** Core platform genesis/foundation  
**Priority:** P1 - High importance

#### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+
Focus: Core platform architecture
```

#### Deprecation Analysis
```yaml
Recommendation: AUDIT relationship to primary deployment
Migration Complexity: Unknown (could be foundation layer)
Unique Features: Platform genesis components
Deprecation Priority: P2 - After architecture review
```

---

### 13-17. v0-* Generated Deployments

#### v0-ai-agent-builder-woad-ten.vercel.app
**Purpose:** AI agent builder (v0.dev template)  
**Status:** 🟡 Unverified  
**Origin:** v0.dev

#### v0-ai-powered-animation-studio-pied.vercel.app
**Purpose:** Animation studio tool  
**Status:** 🟡 Unverified  
**Origin:** v0.dev

#### v0-eleven-labs-agents-starter-inky.vercel.app
**Purpose:** ElevenLabs AI agents integration  
**Status:** 🟡 Unverified  
**Origin:** v0.dev  
**Integration:** ElevenLabs API

#### v0-template-evaluation-academy.vercel.app
**Purpose:** Template evaluation/testing system  
**Status:** 🟡 Unverified  
**Origin:** v0.dev  
**Priority:** P1 - Possibly core product feature

#### v0-nano-banana-starter-psi-two.vercel.app
**Purpose:** Nano Banana AI starter template  
**Status:** 🟡 Unverified  
**Origin:** v0.dev

#### Shared v0-* Characteristics
```yaml
Runtime: Node.js 18.x or 20.x
Framework: Next.js 13+ (v0.dev default)
Styling: Tailwind CSS + shadcn/ui
Build Command: npm run build
Hash Suffixes: -woad-ten, -pied, -inky, -psi-two (v0.dev pattern)
```

#### Shared Environment Variables
```bash
# v0.dev Deployments
NEXT_PUBLIC_APP_URL=<deployment_url>
OPENAI_API_KEY=<key_if_ai_features>

# Specific to ElevenLabs variant
ELEVENLABS_API_KEY=<key>
```

#### Deprecation Analysis (All v0-* Deployments)
```yaml
Recommendation: AUDIT for unique features, consolidate into main platform
Migration Complexity: Low-Medium (template-based, modular)
Unique Features:
  - AI agent builder components
  - Animation studio tools
  - ElevenLabs integration
  - Template evaluation system
  - Nano Banana AI integration
Deprecation Priority: P2 - After feature extraction (1-2 months)
```

---

## Consolidated Recommendations

### Target Architecture (5 Vercel Deployments)

1. **Production:** flashfusion.vercel.app → flashfusion.io
   - Consolidate: app-generator, universal, genesis features
   - Cost: $20/mo (Pro tier)

2. **Staging:** flashfusion-staging.vercel.app
   - Consolidate: beta, staging-abc456
   - Cost: $0 (Hobby tier)

3. **Development:** flashfusion-dev.vercel.app (create new)
   - For active feature development
   - Cost: $0 (Hobby tier)

4. **Preview:** Auto-generated (preview-xyz123 pattern)
   - PR-based preview deployments
   - Cost: $0 (included)

5. **Experimental:** flashfusion-lab.vercel.app (create new)
   - Consolidate: v0-* deployments, specialized tools
   - Cost: $0 (Hobby tier)

### Deprecation Timeline

**Phase 1 (Week 1):** Immediate deletion
- [ ] flashfusion-react-migration.vercel.app (abandoned)
- [ ] flashfusion-next.vercel.app (use preview deployments)

**Phase 2 (Month 1):** Feature extraction + consolidation
- [ ] flashfusion-app-generator → Production
- [ ] flashfusion-wizard-v2 → Production
- [ ] flashfusion-platform-builder → Production (if active)
- [ ] flashfusion-universal → Production
- [ ] flashfusion-genesis → Production

**Phase 3 (Month 2):** Staging consolidation
- [ ] flashfusion-beta → Staging
- [ ] flashfusion-staging-abc456 → Staging (rename)

**Phase 4 (Month 2-3):** v0-* template consolidation
- [ ] Extract unique features from 5 v0-* deployments
- [ ] Integrate into Experimental or Production
- [ ] Archive template code for reference

**Phase 5 (Month 3):** Specialized tools evaluation
- [ ] int-smart-triage-ai-2-0 → Integrate or deprecate
- [ ] All remaining → Archived or deleted

**Result:** 17 → 5 deployments (71% reduction)

---

## Infrastructure Details

### Vercel Configuration (Assumed Standard)

```json
// vercel.json
{
  "version": 2,
  "buildCommand": "npm run build",
  "devCommand": "npm run dev",
  "installCommand": "npm install",
  "framework": "nextjs",
  "outputDirectory": ".next",
  "regions": ["iad1", "sfo1", "cdg1"],
  "env": {
    "DATABASE_URL": "@database-url",
    "NEXT_PUBLIC_SUPABASE_URL": "@supabase-url"
  },
  "build": {
    "env": {
      "NEXT_TELEMETRY_DISABLED": "1"
    }
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "Referrer-Policy",
          "value": "origin-when-cross-origin"
        },
        {
          "key": "Permissions-Policy",
          "value": "camera=(), microphone=(), geolocation=()"
        }
      ]
    }
  ],
  "rewrites": [
    {
      "source": "/api/:path*",
      "destination": "/api/:path*"
    }
  ]
}
```

### Security Configuration

```yaml
# Security Best Practices (To Validate)
Environment Variables:
  Storage: Vercel Environment Variables (encrypted)
  Rotation: Quarterly (recommended)
  Access: Team-based (not individual)

Authentication:
  Method: Supabase Auth
  Providers: Email, Google, GitHub (assumed)
  Session: JWT with httpOnly cookies

Authorization:
  Database: Supabase RLS policies
  API: Middleware-based route protection

Secrets Management:
  Platform: Vercel Secrets
  External: 1Password/AWS Secrets Manager (recommended)
  Rotation: Automated (recommended)

CORS:
  Allowed Origins:
    - https://flashfusion.io
    - https://*.flashfusion.io
    - https://flashfusion.vercel.app
  Methods: GET, POST, PUT, DELETE, OPTIONS
  Credentials: true (for cookies)
```

---

## Monitoring & Operations

### Recommended Monitoring Stack

```yaml
# Application Performance Monitoring
APM: Sentry or Datadog
  - Error tracking
  - Performance monitoring
  - Release tracking

# Uptime Monitoring
Service: UptimeRobot (free tier: 50 monitors)
Targets:
  - flashfusion.vercel.app (1 min interval)
  - flashfusion.io (1 min interval)
  - flashfusion-staging.vercel.app (5 min interval)

# Log Aggregation
Platform: Vercel Log Drains → Datadog/Logtail
Retention: 30 days (recommended)
Alerting: Error rate > 1% for 5 minutes

# Analytics
Platform: Vercel Analytics (built-in)
Metrics: Web Vitals, Traffic, Top Pages
Export: BigQuery (for advanced analysis)
```

### Operational Runbook

```yaml
# Deployment Process
1. Development:
   - Local: npm run dev
   - Preview: Auto-deploy on PR creation
   - Review: Team review + preview link testing

2. Staging:
   - Trigger: Merge to `develop` branch
   - Tests: E2E tests via GitHub Actions
   - Approval: QA team sign-off

3. Production:
   - Trigger: Merge to `main` branch
   - Canary: 10% traffic for 10 minutes (optional)
   - Full Deploy: 100% traffic
   - Rollback: Instant via Vercel dashboard

# Incident Response
1. Detection: Uptime alert or error spike
2. Triage: Check Vercel dashboard + Sentry
3. Mitigation: Rollback to previous deployment
4. Resolution: Fix + redeploy
5. Postmortem: Document in Notion/Confluence

# Maintenance Windows
- Preferred: Tuesday/Wednesday 2-4 AM PST
- Communication: 48 hours notice (email + status page)
- Duration: <1 hour target
```

---

## Cost Optimization

### Current Estimate (17 Deployments)

```yaml
Scenario 1: All Hobby Tier
  Cost: $0/month
  Risk: Build minute limits (6,000/mo total)

Scenario 2: Mixed (1 Pro, 16 Hobby)
  Cost: $20/month
  Coverage: Primary production on Pro

Scenario 3: All Pro Tier
  Cost: $340/month
  Unnecessary: Most deployments don't need Pro
```

### Target State (5 Deployments)

```yaml
Production (Pro): $20/month
  - Unlimited builds
  - 1 TB bandwidth
  - Team collaboration

Staging (Hobby): $0/month
Experimental (Hobby): $0/month
Dev (Hobby): $0/month
Preview (Auto): $0/month (included)

Total: $20/month
Savings: $0-320/month (depending on current actual spend)
```

---

## Validation Checklist

### Required Actions

**Phase 1: Discovery**
- [ ] Access Vercel dashboard: https://vercel.com/dashboard
- [ ] List all 17 projects
- [ ] Identify actual tier per deployment
- [ ] Extract environment variable schemas (no values)
- [ ] Download `vercel.json` configs
- [ ] Check GitHub repository connections

**Phase 2: Verification**
- [ ] Test each URL from external network
- [ ] Confirm operational status
- [ ] Check last deployment date
- [ ] Review build logs for errors
- [ ] Audit custom domain configurations

**Phase 3: Documentation Update**
- [ ] Update this spec with actual configs
- [ ] Map GitHub repos to deployments
- [ ] Document unique features per deployment
- [ ] Create feature extraction plan

---

## Related Documentation

- [Master Specifications Index](computer:///mnt/user-data/outputs/specs/00-master-index.md)
- [Custom Domains Spec](computer:///mnt/user-data/outputs/specs/custom-domains-spec.md)
- [Extended Deployment Inventory](computer:///mnt/user-data/outputs/extended-deployment-inventory.md)

---

**Document Status:** Draft - Requires Dashboard Validation  
**Last Updated:** 2025-11-22  
**Next Review:** After Vercel dashboard audit
