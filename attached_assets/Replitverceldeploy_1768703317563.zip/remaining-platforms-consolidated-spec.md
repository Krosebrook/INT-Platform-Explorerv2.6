# Remaining Platforms - Consolidated Specifications
## 48 Deployments Across 9 Platforms

**Generated:** 2025-11-22  
**Platforms Covered:** Base44, Netlify, Bolt, Lovable, Encr.app, Blink, Leapcell, Mocha, Custom Domains  
**Total Deployments:** 48  
**Estimated Cost:** $0-150/month (varies by platform)

---

## Quick Reference

| Platform | Count | Status | Priority | Cost Est | Action |
|----------|-------|--------|----------|----------|--------|
| Custom Domains | 11 | 🟡 DNS Unknown | P0 | $12/yr | Validate & Configure |
| Base44 | 12 | 🟡 Unverified | P2 | Unknown | Audit for deprecation |
| Bolt | 8 | 🟡 Unverified | P3 | $0 | Consolidate or delete |
| Netlify | 5 | 🟡 Unverified | P3 | $0-95 | Evaluate vs Vercel |
| Lovable | 4 | 🟡 Unverified | P3 | $0-80 | Extract features |
| Encr.app | 3 | 🟡 Staging Only | P2 | Unknown | Integrate or deprecate |
| Blink | 3 | 🟡 Unverified | P4 | $0 | Likely delete |
| Leapcell | 2 | 🟡 Unverified | P3 | Unknown | Evaluate tools |
| Mocha | 1 | 🟡 Unverified | P4 | $0 | Likely delete |

---

## Platform 1: Custom Domains (11 deployments) - P0

### flashfusion.io Domain Family

#### Primary Domains (4)

**1. flashfusion.io** ⭐
```yaml
Status: 🟡 DNS Unknown
Purpose: Root domain / landing page
Priority: P0 - CRITICAL
Target: Should point to flashfusion.vercel.app
DNS Config Required:
  Type: CNAME or A record
  Value: cname.vercel-dns.com or Vercel IP
SSL: Auto via Vercel
```

**2. app.flashfusion.io**
```yaml
Status: 🟡 DNS Unknown
Purpose: Main application
Target: flashfusion.vercel.app
DNS: CNAME to cname.vercel-dns.com
```

**3. wizard.flashfusion.io**
```yaml
Status: 🟡 DNS Unknown
Purpose: Configuration wizard
Target: flashfusion.vercel.app (subdomain routing)
```

**4. beta.flashfusion.io**
```yaml
Status: 🟡 DNS Unknown
Purpose: Beta features
Target: flashfusion-staging.vercel.app
```

#### Additional Custom Vercel Deployments (7)

Specialized deployments with v0-generated names:
- v0-storefront-w-nano-banana-ai-s-red-sigma.vercel.app
- v0-ai-elements-with-ai-sdk-5-phi-sand.vercel.app
- (Others from Vercel spec)

### Required Actions

```yaml
Immediate (Day 1):
  1. Verify domain registration
     - Registrar: Namecheap/GoDaddy/Cloudflare?
     - Expiration date
     - Auto-renewal status
  
  2. Configure DNS
     - Add CNAME: flashfusion.io → cname.vercel-dns.com
     - Add CNAME: app → cname.vercel-dns.com
     - Add CNAME: wizard → cname.vercel-dns.com
     - Add CNAME: beta → cname.vercel-dns.com
     - Add CNAME: api → (future API gateway)
     - Add CNAME: docs → (future docs site)
     - Add CNAME: status → (status page)
  
  3. Verify in Vercel
     - Add custom domains to Vercel project
     - Wait for SSL provisioning (auto)
     - Test HTTPS access

Week 1:
  4. Implement 301 redirects
     - All platform URLs → flashfusion.io
     - SEO preservation
  
  5. Update branding
     - All documentation → flashfusion.io
     - Email signatures
     - Social media profiles
```

---

## Platform 2: Base44 (12 deployments) - P2

### Old Pattern: .app.base44.io (5)

1. flashfusion.app.base44.io
2. base44-ai-web-2.app.base44.io
3. flashfusion-official.app.base44.io
4. flashfusion-wizard.app.base44.io
5. platform-wizard.app.base44.io

### New Pattern: .base44.app (7)

6. arch-designer-copy-8d691fc3.base44.app
7. archon-orchestrator-8b0fae36.base44.app
8. sole-ignite-5d9c7db5.base44.app
9. sedona-soul-sessions-a2475eec.base44.app
10. flash-fusion-4e98fe60.base44.app
11. aura-flow-ef4207d1.base44.app
12. fusion-ai-565c8e16.base44.app

### Technical Stack (Assumed)

```yaml
Runtime: Node.js 18.x or 20.x
Framework: Next.js or standalone React
Deployment: Hash-based auto-generation
Purpose: Experimental/prototype platform
```

### Cost Unknown - Requires Dashboard Access

**Base44 Platform:** https://base44.io

### Analysis & Recommendations

```yaml
Pattern Analysis:
  - Hash-based URLs suggest template/auto-generation
  - Specialized names (arch-designer, orchestrator) suggest feature testing
  - Domain inconsistency (.app.base44.io vs .base44.app) suggests platform migration

Business Value: LOW
  - Experimental platform
  - Hash URLs not production-ready
  - Vercel preferred for production

Recommendation: DEPRECATE ALL
  Priority: P2 (after feature extraction)
  Timeline: 1-2 months
  
  Steps:
    1. Audit unique features per deployment
    2. Extract valuable prototypes
    3. Archive code to GitHub
    4. Delete all 12 Base44 deployments
    5. Cancel Base44 subscription
  
  Savings: Unknown (est $20-100/mo if paid tier)
```

---

## Platform 3: Bolt (8 deployments) - P3

### Bolt.new Pattern (3)

1. flashfusion.bolt.new
2. flashfusion-wizard.bolt.new
3. flashfusion-v2.bolt.new

### Bolt.host Pattern (5)

4. krosebrook-open-lova-1ldf.bolt.host
5. krosebrook-int-smart-uc4m.bolt.host
6. flashfusion-design-s-2hy9.bolt.host
7. enterprise-knowledge-us5l.bolt.host
8. universal-ai-app-gen-mz5j.bolt.host

### Platform Analysis

```yaml
Bolt Platform: AI-powered code generation (StackBlitz)
Cost: $0 (free tier for prototypes)
Use Case: Rapid prototyping, AI-generated apps
Limitations: Not production-grade, cold starts
```

### Recommendations

```yaml
Keep Pattern: bolt.new for experiments
Delete Pattern: bolt.host deployments (outdated)

Consolidation Target: 0-1 deployments
  - Keep 1 for AI experimentation (flashfusion.bolt.new)
  - Delete all bolt.host instances

Priority: P3 (Low business impact)
Timeline: 1 month
Savings: $0 (already free)
```

---

## Platform 4: Netlify (5 deployments) - P3

### Deployments

1. flashfusion.netlify.app
2. flashfusion-beta.netlify.app
3. flashfusion-dev.netlify.app
4. radiant-elf-684899.netlify.app (auto-generated)
5. genesiszulu.netlify.app (branded)

### Technical Stack

```yaml
Runtime: Node.js 18.x/20.x
Framework: Next.js or Static React
Build: Netlify Build System
CDN: Global Edge Network
Cost: $0-$19/mo per site (Starter to Pro)
```

### Cost Estimate

```yaml
Scenario 1: All Starter (free)
  Cost: $0/month
  Limits: 100 GB bandwidth, 300 build minutes

Scenario 2: Mixed (1 Pro, 4 Starter)
  Cost: $19/month

Total Unknown: $0-95/month
```

### Recommendations

```yaml
Comparison: Netlify vs Vercel
  - Vercel: Better Next.js integration
  - Netlify: Better static site handling
  - Both: Excellent CDN, auto SSL

Decision: CONSOLIDATE to Vercel
  Rationale: Already on Vercel for primary, reduce platform complexity
  
Action Plan:
  1. Audit Netlify-specific features (none expected)
  2. Migrate to Vercel if no blockers
  3. Delete all 5 Netlify deployments
  4. Cancel Netlify subscription

Priority: P3
Timeline: 1 month
Savings: $0-95/month
```

---

## Platform 5: Lovable (4 deployments) - P3

### Deployments

1. flashfusion.lovable.app
2. flashfusion-wizard.lovable.app
3. flashfusion-generator.lovable.app
4. cortex-second-brain-4589.lovable.app

### Platform Analysis

```yaml
Lovable Platform: AI-powered app builder (similar to v0.dev)
Cost: $0-$20/mo per project
Use Case: Rapid UI prototyping
Limitation: Not production-grade
```

### Recommendations

```yaml
Action: EXTRACT UNIQUE FEATURES → DELETE
  
Notable: cortex-second-brain-4589
  - Second brain / knowledge management tool
  - Audit for integration into main platform
  
Timeline:
  Week 1: Audit unique features
  Week 2: Extract code/designs
  Week 3: Delete all Lovable deployments

Priority: P3
Savings: $0-80/month
```

---

## Platform 6: Encr.app (3 deployments) - P2 🔍

### Deployments (All Staging)

1. **staging-security-blindspot-radar-kzzi.frontend.encr.app**
   - Purpose: Security vulnerability scanning
   - Value: HIGH - Security tooling

2. **staging-saas-validator-suite-aeci.frontend.encr.app**
   - Purpose: SaaS validation/testing
   - Value: MEDIUM - QA tooling

3. **staging-lead-book-close-crm-n5w2.frontend.encr.app**
   - Purpose: CRM system
   - Value: HIGH - Sales tooling

### Analysis - UNDOCUMENTED PRODUCTS

```yaml
Discovery: These are specialized tools, not FlashFusion variants
Status: All marked "staging" - not production yet
Platform: Encr.app (lesser-known, research required)

Critical Questions:
  1. Are these part of FlashFusion product suite?
  2. Or separate SaaS products in development?
  3. Are they customer-facing or internal tools?
  4. Who is the product owner?

Recommendation: DO NOT DELETE until purpose clarified
Priority: P2 - URGENT product/business clarification needed
Action: Meet with product/business stakeholders
```

### Technical Stack (Assumed)

```yaml
Platform: Encr.app
Pattern: staging-<name>-<hash>.frontend.encr.app
Runtime: Unknown (likely Node.js)
Status: Pre-production staging
```

---

## Platform 7: Blink (3 deployments) - P4

1. flashfusion.blink.app
2. flashfusion-wizard.blink.app
3. universal-blindspot-radar-9g20dr1d.sites.blink.new

### Recommendations

```yaml
Action: DELETE ALL
Rationale: Blink.app is experimental platform, low business value
Priority: P4 (lowest)
Timeline: 2 months (after higher priorities)
Savings: $0 (free tier)
```

---

## Platform 8: Leapcell (2 deployments) - P3

1. **knowledge-base-app-d2jaq7482vjjq7aes2g0.lp.dev**
   - Purpose: Internal wiki/documentation
   - Value: MEDIUM

2. **project-nexus-database-schema-d3eqmd482vjnoj28ngcg.lp.dev**
   - Purpose: DB schema visualization
   - Value: LOW (use dbdiagram.io instead)

### Recommendations

```yaml
Knowledge Base:
  Evaluate: Notion vs custom knowledge base
  If Notion: Migrate content, delete deployment
  If Custom: Keep or migrate to Vercel

DB Schema Tool:
  Replace with: dbdiagram.io or Prisma Studio
  Action: DELETE

Priority: P3
Timeline: 1 month
```

---

## Platform 9: Mocha (1 deployment) - P4

1. r3c55aochlnru.mocha.app

```yaml
Status: Unknown purpose
Action: Investigate → likely delete
Priority: P4
```

---

## Master Consolidation Plan

### Phase 1: Validation (Week 1)

```yaml
Custom Domains:
  [ ] Verify flashfusion.io registration
  [ ] Configure DNS
  [ ] Test HTTPS access

All Platforms:
  [ ] Test each URL from external network
  [ ] Document operational status
  [ ] Identify active vs abandoned
```

### Phase 2: Critical Decisions (Week 2)

```yaml
Encr.app (P2):
  [ ] Meeting with stakeholders
  [ ] Clarify product strategy
  [ ] Decide: integrate, spin off, or deprecate

Custom Domains (P0):
  [ ] Complete DNS configuration
  [ ] Implement 301 redirects
  [ ] Update all documentation
```

### Phase 3: Platform Consolidation (Month 1-2)

```yaml
Delete Immediately (P1):
  [ ] Base44: All 12 deployments
  [ ] Bolt.host: 5 deployments
  [ ] Blink: 3 deployments
  [ ] Mocha: 1 deployment
  Total: 21 deletions

Extract & Delete (P2):
  [ ] Lovable: 4 deployments (extract features)
  [ ] Netlify: 5 deployments (migrate to Vercel)
  [ ] Leapcell: 2 deployments (evaluate first)
  Total: 11 consolidations

Keep & Configure (P0):
  [ ] Custom Domains: 4 (flashfusion.io family)
```

### Phase 4: Final State (Month 3)

```yaml
Target: 4 custom domains pointing to 5 Vercel deployments

Retained Infrastructure:
  - flashfusion.io (Vercel)
  - app.flashfusion.io (Vercel)
  - wizard.flashfusion.io (Vercel)
  - beta.flashfusion.io (Vercel)
  - Vercel: 5 deployments
  - Replit: 2-3 deployments (Teams)
  - Encr.app: 0-3 (pending decision)

Total: 7-10 deployments (down from 77)
Reduction: 87-91%
```

---

## Cost Summary

### Current State (All Platforms)

```yaml
Custom Domains: $12/year (flashfusion.io)
Base44: $0-100/month (unknown)
Netlify: $0-95/month
Bolt: $0 (free tier)
Lovable: $0-80/month
Encr.app: Unknown
Blink: $0 (free tier)
Leapcell: Unknown
Mocha: $0 (free tier)

Total: $12/year + $0-275+/month
```

### Target State

```yaml
Custom Domain: $12/year
Vercel: $20/month (Pro)
Replit: $20/month (Teams)
Encr.app: $0-50/month (if retained)

Total: $12/year + $40-90/month
Savings: $0-185+/month
```

---

## Validation Checklist

### Per-Platform Actions

```yaml
Custom Domains:
  [ ] Check domain registrar
  [ ] Verify expiration & auto-renew
  [ ] Configure DNS records
  [ ] Add to Vercel custom domains
  [ ] Test HTTPS access

Base44:
  [ ] Access https://base44.io dashboard
  [ ] List all 12 projects
  [ ] Check billing
  [ ] Export environment variables
  [ ] Download code archives

Netlify:
  [ ] Access https://app.netlify.com
  [ ] List 5 sites
  [ ] Check billing
  [ ] Audit netlify.toml configs
  [ ] Plan Vercel migration

(Repeat for each platform)
```

---

## Related Documentation

- [Master Specifications Index](computer:///mnt/user-data/outputs/specs/00-master-index.md)
- [Vercel Deployments Spec](computer:///mnt/user-data/outputs/specs/vercel-deployments-spec.md)
- [Replit Deployments Spec](computer:///mnt/user-data/outputs/specs/replit-deployments-spec.md)
- [Extended Deployment Inventory](computer:///mnt/user-data/outputs/extended-deployment-inventory.md)

---

**Document Status:** Consolidated Specifications - 9 Platforms  
**Last Updated:** 2025-11-22  
**Next Review:** After platform dashboard audits complete
