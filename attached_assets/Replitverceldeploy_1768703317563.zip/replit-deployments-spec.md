# Replit Deployments - Complete Specifications
## 11 Instances | Development Platform | ⚠️ PERSONAL ACCOUNT RISK

**Generated:** 2025-11-22  
**Platform:** Replit  
**Total Deployments:** 11  
**Status:** 🔴 Risk - Personal Account Ownership  
**Monthly Cost Estimate:** $0-$77 (Free to Core tier)

---

## ⚠️ CRITICAL RISK ALERT

**Personal Account Pattern Detected:**  
6 out of 11 deployments use `*-kylerosebrook.replit.app` naming pattern, indicating single-user ownership.

**Business Risk:**
- **Bus Factor = 1:** All deployments tied to personal account
- **No Team Access:** Other team members cannot manage/deploy
- **Account Lockout Risk:** 2FA issues, password reset, or account suspension = total outage
- **Audit Trail Gap:** Personal account activity not in company systems

**Immediate Action Required:**
1. Create Replit Teams account
2. Transfer ownership of 6 personal deployments
3. Grant team member access
4. Document admin credentials in company vault

---

## Platform Overview

### Replit Tiers

| Tier | Cost/mo | Storage | Compute | Deployments | Always-On |
|------|---------|---------|---------|-------------|-----------|
| Free | $0 | 500 MB | Shared | 3 | No |
| Core | $7 | 10 GB | 0.5 vCPU | Unlimited | 1 |
| Teams | $20 | 50 GB | 2 vCPU | Unlimited | 5 |

### Strategic Assessment
- **Use Case:** Development, staging, microservices
- **Strengths:** Fast spin-up, collaborative IDE, free tier generous
- **Weaknesses:** Cold starts on free tier, less enterprise-ready than Vercel
- **Recommendation:** Consolidate to 2-3 deployments, migrate to Teams tier

---

## Deployment Inventory

### Personal Account Deployments (6) 🚨

#### 1. auth-connect-kylerosebrook.replit.app

**Status:** 🔴 Personal Account  
**Purpose:** Authentication microservice  
**Priority:** P0 - CRITICAL INFRASTRUCTURE

##### Technical Stack
```yaml
Runtime: Node.js 18.x or 20.x
Framework: Express.js or Fastify (API-focused)
Purpose: OAuth/SSO authentication service
```

##### Environment Variables (Critical)
```bash
# Auth Providers
GOOGLE_CLIENT_ID=<google_oauth_id>
GOOGLE_CLIENT_SECRET=<google_oauth_secret>
GITHUB_CLIENT_ID=<github_oauth_id>
GITHUB_CLIENT_SECRET=<github_oauth_secret>

# Session Management
SESSION_SECRET=<random_secret_key>
JWT_SECRET=<jwt_signing_key>
REDIS_URL=<redis_session_store>

# Database
SUPABASE_URL=<supabase_url>
SUPABASE_SERVICE_KEY=<service_role_key>

# Callbacks
CALLBACK_URL=https://auth-connect-kylerosebrook.replit.app/callback
ALLOWED_ORIGINS=https://flashfusion.vercel.app,https://flashfusion.io
```

##### Security & Access
```yaml
Authentication: N/A (this IS the auth service)
Authorization: API key validation
CORS: Restricted to FlashFusion domains
Rate Limiting: Required (100 req/min recommended)
```

##### Deprecation Analysis
```yaml
Recommendation: URGENT - Transfer to Teams, rename to auth.flashfusion.io
Migration Complexity: HIGH - Critical infrastructure, requires zero-downtime migration
Unique Features: Centralized authentication for all deployments
Deprecation Priority: P0 - Transfer ownership immediately, keep service
```

---

#### 2. spud-signup-kylerosebrook.replit.app

**Status:** 🔴 Personal Account  
**Purpose:** Specialized signup flow (SPUD system)  
**Priority:** P2 - Product feature

##### Technical Stack
```yaml
Runtime: Node.js 18.x
Framework: Next.js or standalone React app
Purpose: Onboarding/signup wizard
```

##### Environment Variables
```bash
# API Integration
AUTH_API_URL=https://auth-connect-kylerosebrook.replit.app
MAIN_APP_URL=https://flashfusion.vercel.app

# Email Service
SENDGRID_API_KEY=<sendgrid_key>
FROM_EMAIL=signup@flashfusion.io

# Analytics
MIXPANEL_TOKEN=<token>
GOOGLE_ANALYTICS_ID=<ga_id>
```

##### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE into main flashfusion.vercel.app
Migration Complexity: MEDIUM - Signup flow extraction
Unique Features: SPUD-specific onboarding (clarify what SPUD is)
Deprecation Priority: P2 - After feature audit (1 month)
```

---

#### 3. sole-much-better-kylerosebrook.replit.app

**Status:** 🔴 Personal Account  
**Purpose:** Unknown - "sole-much-better" is cryptic  
**Priority:** P3 - Investigate purpose

##### Technical Stack
```yaml
Runtime: Unknown
Framework: Unknown
Purpose: Requires investigation
```

##### Deprecation Analysis
```yaml
Recommendation: AUDIT purpose → consolidate or delete
Migration Complexity: UNKNOWN
Unique Features: UNKNOWN
Deprecation Priority: P3 - Investigate, likely delete
```

---

#### 4. dev-chat-kylerosebrook.replit.app

**Status:** 🔴 Personal Account  
**Purpose:** Chat interface/widget (development)  
**Priority:** P2 - Feature component

##### Technical Stack
```yaml
Runtime: Node.js 18.x
Framework: React + WebSocket server
Purpose: Real-time chat widget
```

##### Environment Variables
```bash
# WebSocket
WS_PORT=3001
WS_ORIGIN=https://flashfusion.vercel.app

# Chat Backend
CHAT_API_URL=<chat_api>
PUSHER_APP_ID=<pusher_id> # Or Socket.io
PUSHER_KEY=<key>
PUSHER_SECRET=<secret>

# AI Features (if AI chat)
OPENAI_API_KEY=<key>
ANTHROPIC_API_KEY=<key>
```

##### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE into main platform
Migration Complexity: MEDIUM - WebSocket infrastructure
Unique Features: Real-time chat, possibly AI-powered
Deprecation Priority: P2 - Migrate core component (1 month)
```

---

#### 5. flash-fusion-1-kylerosebrook.replit.app

**Status:** 🔴 Personal Account  
**Purpose:** Early FlashFusion prototype or variant  
**Priority:** P3 - Historical artifact

##### Technical Stack
```yaml
Runtime: Node.js (older version?)
Framework: Unknown (early prototype)
Purpose: Version 1 or experimental build
```

##### Deprecation Analysis
```yaml
Recommendation: ARCHIVE code → DELETE deployment
Migration Complexity: LOW (historical only)
Unique Features: None (superceded by current platform)
Deprecation Priority: P1 - Delete after code archive
```

---

### Shared Replit Deployments (5)

#### 6. flashfusion.replit.app

**Status:** 🟡 Unverified (but likely shared account)  
**Purpose:** Primary Replit deployment  
**Priority:** P1 - Keep as dev/staging

##### Technical Stack
```yaml
Runtime: Node.js 20.x
Framework: Next.js 14+ (aligned with Vercel)
Environment: Development or Staging
```

##### Environment Variables
```bash
NEXT_PUBLIC_ENVIRONMENT=development
DATABASE_URL=<dev_database>
# Other vars similar to Vercel deployments
```

##### Deprecation Analysis
```yaml
Recommendation: KEEP - Rename to flashfusion-dev.replit.app
Migration Complexity: LOW
Unique Features: Primary Replit dev environment
Deprecation Priority: N/A - Consolidation target
```

---

#### 7. flashfusion-wizard.replit.app

**Status:** 🟡 Unverified  
**Purpose:** Wizard component testing  
**Priority:** P3 - Likely duplicate

##### Deprecation Analysis
```yaml
Recommendation: CONSOLIDATE with flashfusion.replit.app
Migration Complexity: LOW
Unique Features: None (wizard in main app)
Deprecation Priority: P2 - Consolidate within 1 month
```

---

#### 8. flashfusion-universal.replit.app

**Status:** 🟡 Unverified  
**Purpose:** Universal app generator on Replit  
**Priority:** P3 - Duplicate of Vercel deployments

##### Deprecation Analysis
```yaml
Recommendation: DELETE - Use Vercel for this
Migration Complexity: N/A
Unique Features: None (duplicate)
Deprecation Priority: P1 - Delete immediately
```

---

#### 9. flashfusion-dev.replit.app

**Status:** 🟡 Unverified  
**Purpose:** Development environment  
**Priority:** P1 - Keep

##### Deprecation Analysis
```yaml
Recommendation: KEEP as primary dev environment
Migration Complexity: N/A
Unique Features: Active development target
Deprecation Priority: N/A - Target deployment
```

---

#### 10. flashfusion-staging.replit.app

**Status:** 🟡 Unverified  
**Purpose:** Staging environment  
**Priority:** P2 - Evaluate vs. Vercel staging

##### Deprecation Analysis
```yaml
Recommendation: EVALUATE - May be redundant with Vercel staging
Migration Complexity: LOW
Unique Features: Replit-specific staging (if needed)
Deprecation Priority: P2 - Consolidate platforms
```

---

## Migration Plan: Personal → Teams

### Phase 1: Replit Teams Setup (Day 1)

```yaml
Actions:
  1. Create Replit Teams account
     - Team name: flashfusion-team or company name
     - Billing: $20/month
  
  2. Invite team members
     - Add minimum 2 admins
     - Add all developers with appropriate roles
  
  3. Document credentials
     - Store in 1Password/company vault
     - Share with designated admins only
```

### Phase 2: Ownership Transfer (Day 2-3)

```yaml
Critical Services (Zero-Downtime Required):
  Priority: auth-connect-kylerosebrook.replit.app
  
  Steps:
    1. Create new Repl in Teams account: auth-connect-flashfusion
    2. Clone code from personal account
    3. Configure environment variables in Teams Repl
    4. Deploy and test in Teams account
    5. Update DNS/URLs to point to new deployment
    6. Monitor for 24 hours
    7. Archive personal account version (don't delete yet)
  
  Downtime: 0 seconds (blue-green deployment)
```

```yaml
Non-Critical Services:
  - spud-signup-kylerosebrook
  - dev-chat-kylerosebrook
  - flash-fusion-1-kylerosebrook
  - sole-much-better-kylerosebrook
  
  Steps:
    1. Clone to Teams account
    2. Update environment variables
    3. Deploy
    4. Update references
    5. Delete from personal account after 1 week
  
  Acceptable Downtime: 5-10 minutes per service
```

### Phase 3: Consolidation (Week 2-3)

```yaml
Target Architecture (2-3 Replit Deployments):
  
  1. flashfusion-dev.replit.app (Teams)
     - Consolidate: flashfusion, flashfusion-wizard, flashfusion-universal
     - Purpose: Active development environment
  
  2. auth-service.replit.app (Teams)
     - Former: auth-connect-kylerosebrook
     - Purpose: Centralized authentication microservice
     - Consider: Migrate to Vercel Edge Functions
  
  3. flashfusion-staging.replit.app (Teams) [OPTIONAL]
     - Keep only if Vercel staging insufficient
     - Otherwise: Deprecate
```

---

## Security Hardening

### Required Actions

```yaml
1. Environment Variables:
   - Audit all 11 deployments
   - Rotate all secrets after Teams migration
   - Move secrets to Teams environment variables (encrypted)

2. Access Control:
   - Enable 2FA for all team members
   - Implement role-based access (admin/developer/viewer)
   - Remove personal account access after migration

3. Secrets Management:
   - Integrate with 1Password/AWS Secrets Manager
   - Auto-rotate API keys quarterly
   - Never commit secrets to Git (use .env.example templates)

4. Monitoring:
   - Set up UptimeRobot for critical services (auth-connect)
   - Configure Sentry error tracking
   - Alert on-call rotation for auth service downtime
```

---

## Cost Analysis

### Current State (Estimated)

```yaml
Scenario 1: All Free Tier
  Cost: $0/month
  Risk: Cold starts, limited storage, no always-on

Scenario 2: kylerosebrook has Core ($7)
  Cost: $7/month
  Coverage: 1 always-on deployment (likely auth-connect)
  Risk: Still personal account

Scenario 3: Multiple Core subscriptions
  Cost: $0-77/month
  Uncertainty: Unknown tier distribution
```

### Target State (Teams)

```yaml
Replit Teams: $20/month
  - 50 GB storage
  - 2 vCPU compute
  - 5 always-on deployments
  - Team collaboration
  - Shared ownership

Deployments: 2-3 (down from 11)
  - flashfusion-dev (always-on)
  - auth-service (always-on)
  - flashfusion-staging (optional, always-on)

Total: $20/month
Savings: $0-57/month + eliminated bus factor risk
```

---

## Technical Specifications

### Replit Configuration Files

#### `.replit` (Deprecated but may exist)
```toml
run = "npm start"
language = "nodejs"

[nix]
channel = "stable-21_11"

[env]
NODE_ENV = "production"

[packager]
language = "nodejs"

[packager.features]
packageSearch = true
guessImports = true
```

#### `replit.nix` (Current Standard)
```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.yarn
    pkgs.postgresql
  ];
}
```

#### `.replit.toml` (New Format)
```toml
run = "npm start"
entrypoint = "index.js"

[deployment]
run = ["npm", "start"]
deploymentTarget = "cloudrun"

[[ports]]
localPort = 3000
externalPort = 80
```

### Networking & Ports

```yaml
Default Port: 3000
Public Port: 80 (auto-mapped)
HTTPS: Automatic (*.replit.app has SSL)

Custom Domains:
  - Supported on Core+ tier
  - DNS: CNAME to <repl-name>.<username>.repl.co
  - SSL: Auto-provisioned
```

---

## Operational Runbook

### Deployment Process

```yaml
1. Development:
   - Local: Fork Repl → Edit in Replit IDE
   - Test: Run in Replit (always-on for paid)
   
2. Staging:
   - Deploy: Manual "Run" button or auto-deploy on git push
   - Test: Integration tests
   
3. Production:
   - Replit not recommended for critical production
   - Use Vercel for production-grade deployments
```

### Incident Response

```yaml
1. Auth Service Outage:
   - Priority: P0 (Critical)
   - Escalation: Immediate
   - Mitigation: Restart Repl, check logs
   - Fallback: Direct Supabase Auth (if configured)

2. Dev Environment Down:
   - Priority: P2 (High)
   - Escalation: Business hours
   - Mitigation: Restart Repl
   - Fallback: Local development

3. Cold Start Issues (Free Tier):
   - Expected: 30-60 second wake-up
   - Mitigation: Upgrade to Core for always-on
   - Workaround: Ping endpoint every 5 minutes
```

---

## Validation Checklist

### Phase 1: Account Access
- [ ] Log in to kylerosebrook Replit account
- [ ] List all 11 Repls
- [ ] Identify which tier is active
- [ ] Check billing/subscription status
- [ ] Export environment variables (manual process)

### Phase 2: Technical Audit
- [ ] Test each deployment URL
- [ ] Review `.replit` config files
- [ ] Check dependencies (package.json)
- [ ] Audit database connections
- [ ] Review API integrations

### Phase 3: Migration Prep
- [ ] Create Replit Teams account
- [ ] Document migration plan per service
- [ ] Prepare rollback procedures
- [ ] Schedule maintenance window
- [ ] Communicate to stakeholders

---

## Recommended Actions (Priority Order)

### P0: Critical (This Week)
1. 🔴 **Audit kylerosebrook account access**
   - Verify login credentials
   - Enable 2FA (if not already)
   - Document current configuration

2. 🔴 **Create Replit Teams account**
   - Sign up for $20/mo Teams plan
   - Add minimum 2 admins
   - Set up billing alerts

3. 🔴 **Migrate auth-connect** (Zero-Downtime)
   - Critical authentication service
   - Blue-green deployment strategy
   - 24-hour monitoring period

### P1: High (This Month)
4. 🟡 **Migrate remaining 5 personal deployments**
   - spud-signup, dev-chat, etc.
   - Acceptable downtime: 5-10 min each
   - Complete within 1 week

5. 🟡 **Consolidate 11 → 3 deployments**
   - Dev, auth-service, staging (optional)
   - Archive historical Repls
   - Update documentation

### P2: Medium (Next Month)
6. 🟢 **Evaluate Replit vs. Vercel for auth service**
   - Consider migrating to Vercel Edge Functions
   - Or keep on Replit Teams
   - Decision based on performance metrics

7. 🟢 **Implement monitoring**
   - UptimeRobot for auth service
   - Sentry for error tracking
   - Slack alerts for downtime

---

## Related Documentation

- [Master Specifications Index](computer:///mnt/user-data/outputs/specs/00-master-index.md)
- [Vercel Deployments Spec](computer:///mnt/user-data/outputs/specs/vercel-deployments-spec.md)
- [Extended Deployment Inventory](computer:///mnt/user-data/outputs/extended-deployment-inventory.md)

---

**Document Status:** 🔴 URGENT - Personal Account Risk  
**Last Updated:** 2025-11-22  
**Next Review:** After Teams migration complete
